import java.util.Scanner;
public class ACTIVIDAD_1x01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Dime tres números");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		int num3 = sc.nextInt();
		System.out.println("Estos son los números: " + num1 +num2 + num3);

		

	}

}
